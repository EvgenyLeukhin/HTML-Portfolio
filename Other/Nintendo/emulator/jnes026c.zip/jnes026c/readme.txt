========================================
   Jnes - Nes Emulator for Win95/98
"What a horrible night to have a curse."
========================================

Programmed by Steven Rellinger (Jabo)

=======
Preface
=======

The nes is one of my favorite systems of all time, video games these days are just
missing the gameplay of this old 8-bit system. Games today are overcome with graphical
environments and complex design. 

I wrote his emulator as a personal project which got further than I ever thought, I 
didn't write it because I thought any specific way about other emulators. I felt this
way a good project to further my programming abilities and learn about my favorites
system of course. How long was this in development?, well the earliest archive I have
is from March 14, 1999 so its probably some time around then, development didn't really
get serious until around May of that year though.

Jnes is currently an emulator for Win32 operating systems tested on Win95/98. It uses
DirectX as the method for outputting video/audio. Jnes is freeware, it is not to be 
distributed with games images and it is not to be modified or sold.

This document is best viewed in Notepad or a similar editor at 800x600 or higher
with word wrap off. I feel this documentation is very informative and should answer
just about every question you could have about Jnes.

=========
Revisions
=========

* v0.26c (10/26/99)

- Corrected registry alignment issues
- Saves last directory to registry

* v0.26b (10/23/99)

- PCM channel improvements
- Higher quality audio generation
- Direct Input interface fixes

* v0.26a (10/20/99)

- Direct Input enumerator supports multiple
  gamepads that are under the same name.
- Corrected the new dpcm buffering for games
  that use large buffers with low frequencies.
- Implemented zapper into the via the mouse, 
  preliminary but works in a few games

* v0.26 (10/09/99)

- Added Konami VRC4 Emulation (iNES #21)
- Added Konami VRC2b Emulation (iNES #23)
- Added Konami VRC4b Emulation (iNES #25)
- Added Konami VRC6 Sound Emulation,
   Thanks to Kevin Horton for his docs
- Improved PCM channel emulation
- Minor MMC1/MMC3 mirroring change
- Tweaked MMC3 IRQ
- Fixed 4-window vram
- Support for Controller #2
- Put back correct palette reading
- Fixed game genie length detection
- Major 6502 core optimizations
- MMX enhanced PPU emulation
- DirectSound is now used again
- Dialog for input devices with button config
- Background Sleep is now an option
- Sound output graph

* v0.21 (08/25/99)

- Added MMC4 Emulation (iNES #10)
- Added Sunsoft Mapper #4 (iNES #68)
- Tweaked MMC3 IRQ Slightly
- MMC1 Bankswitching changed
- PPU moved into seperate assembly files
- Fixed a long time Vertical scroll bug
- Minor GameGenie save fix
- Modified the Direct Input Axis mode
- Documentation updated for Sidewinders
- Fixed small windowing problem.
- Removed DirectSound, switched to a 
  hopefully more reliable audio method
- Vsync removed as a result of timing.
- FPS meter disabled in full screen
- Lots of other options were taken out
- Keyboard reading works on NT4 SP4 (DX3)

* v0.20 (08/20/99)

- Fixed triangle frequencies and hold note
- Fixed flag sets when RTI<->NMI<->BRK happens
- Well, RCR/RCL doesn't set ZF
- Added MMC1 512/1024 kb ROM support
- Added Konami VRC6 (iNES #24)
- Added Nintendo MMC2 (iNES #9)
- Better MMC3 IRQ
- Improved Sprite priorities and hits
- Improved Frequency Sweeping
- Preliminary RAW PCM sound emulation
- Noise channel enveloping fixes
- DPCM Irq's Disabled
- Changed save state format to save all audio
  data, added padding for future modifications
- Game Genie Emulation is now alot better
- Support for trained roms
- Sprite priority in 24-bit are better
- Small speed-up in 16-bit rendering

- Windows 98 SE compatible
- Rewritten interface, structured better
- Record wave save dialog box
- Read-only files open now
- Frames per second counter available for full screen
  mode only if Vsync is turned on.
- New Stretch mode added to full screen
- Fixed bitmap writing in RGB555 mode
- Wait for Vsync only affects full screen video mode
- Timing uses new higher performance method
- All threading and program halt problems are fixed

* v0.10 (08/05/99)
- Initial release

======================
Emulation and Features
======================

 CPU
 ===
 - All 6502 opcodes
 - Emulated bugs in the 6502
 - IRQ/NMI
 - Battery backed RAM
 - Written in x86 assembly

 PPU
 ===
 - 8x16 and 8x8 sprites
 - Sprite priority
 - Decent palette
 - Vertical/Horizontal scrolling
 - VROM/VRAM
 - Mirroring methods
 - Written in x86 assembly

 APU
 ===
 - Pulse channels with Frequency sweeps and Decay
 - Triangle
 - Noise
 - Complete PCM channel
 - Konami VRC6 Sound chip

 Mappers
 =======
 - Nintendo; MMC1, MMC2, MMC3, MMC4
 - iNES 2, 3, 6, 7, 8, 11, 21, 23, 24, 25, 66, 69

The following are cool features that are available:

- Full GameGenie support
- Fullscreen/Windowed mode
- Screen capture (BMP)
- Record audio output (WAV)
- Save/Load nes state from file (11 slots)
- Zapper

===================
System Requirements
===================

Windows 95/98
Pentium 133 MHz
Video Card, 2 megs (4 megs for windowed)
DirectX 5.0 with drivers

Video and Sound card drivers are extremely important, download the latest drivers.

Most computers that were made with processors below P166 do not include video cards
capable of 2D hardware acceleration, so if you haven't upgraded your video adapter
and you own one that doesn't include features for DirectDraw you will experience 
severe performance issues.

If you have any questions about your 2D hardware consult the driver info dialog box. If
you video hardware doesn't support stretching to a window Direct Draw will emulate this 
function via software, lowering performance in windowed mode severely.

Full screen video mode performance is better if you have very old video hardware, or
lack large amount of video ram.

Hardware Compatibility
----------------------

This list serves as a list of hardware Jnes was tested on prior to release.  If you 
experience strange performance issues reading this helps. 

This is just a general guide for you to match your hardware up with, I'm not trying
to accumulate a large list of hardware, so there is no need to email your computer
configuration for me to add.

+-----------+-----+---------------+----------------+-------+
| Processor | RAM | Sound Adapter | Video Adapter  |   OS  |
|-----------+-----+---------------+----------------+-------|
| P3 504 OC | 512 | AWE 64        | Viper 770 32MB | Win98 |
| AMD 500   | 256 | AWE 64        | G200 8mb       | Win98 |
| P2 400    | 192 | 16-bit        | ATI Rage Pro   | Win98 |
| P2 400    | 64  | SB 16 PNP     | S3 Virge 2MB*  | Win95 |
| P2 400    | 192 | 16-bit        | ATI Rage Pro   | Win98 |
| P2 350    | 128 | AWE 64        | ATI Rage Pro   | Win98 |
| Cel 333A  | 64  | 16-bit        | Rage IIc 4MB   | Win98 |
| AMD 333   | 96  | Pro Audio Sp  | 3dfx Banshee   | Win98 |
| P233 MMX  | 32  | SB16 PNP      | 3dfx Banshee   | Win95 |
| P166      | 32  | SB16 PNP      | Matrox Myst.   | Win95 |
| Cy686 133 | 80  | SB64 AWE      | Matrox Mill.   | Win98 |
+-----------+-----+---------------+----------------+-------+

(*) = Performed very poorly in windowed mode, full screen performance was better.

The range of computers varies greatly as well as the results on them. I tested from 133
Mhz all the way to 500 to ensure those computers could run this. The S3 Virge was the 
only video card that didnt support clipping to a window, so frame rates suffered severely.

On some video cards 32-bit is alot faster than 24-bit due to the 3 byte format.

Jnes supports the following color formats:
	RGB 8/24/32
	RGB 565 and 555

RGB 8 is only used in full screen mode.

=====================
Overview of interface
=====================

Controls
--------

Default Keyboard Settings:

Select	      = A
Start	      = S

Button (B)   = D
Button (A)   = F

Default Gamepad Settings:

Select	      = 1
Start	      = 2

Button (B)   = 3
Button (A)   = 4

The directional keys on the keyboard and the d-pad on a gamepad are used
for emulating the nes controller's are used for the d-pad.

The buttons are fully configurable via the input dialog for both keyboard
and gamepad input.

Shortcuts
---------

- ESC back to windowed mode in full screen

- F1 Resets
- F2 Toggles pause
- F3 Capture the screen
- F4 Recording sound

- F5 Save a state to file
- F6 Load a state from file

There are a total of 11 save states available. They are selectable via the keys 0 -> 9,
and the "`" which is to the left of "1" on the keyboard. The "`" key represents the
default ".jst" state.

Example: Hit "0" on your keyboard to save to "game".js0, the default slot is "game".jst
The slot is set back to default at the load of a game. 

"Display FPS" will display the number of your frames per second you are getting only for
windowed mode.

Command Line
------------

Load File, "Jnes filename.nes"

-  You may tell Jnes to load a rom on startup by executing Jnes with the filename as the
   parameter. Example: "Jnes zelda.nes", would load zelda.nes on load.

====================
Answers to Questions
====================

Q:	How can I speed Jnes up, I have lower than a P166 and it almost runs why isnt there
	a frame skipping option?
A:	Frameskipping is not implemented as I don't believe in this method to achieve speed, 
	a p166 is a very low system requirement, with a good enough video adapter Jnes runs
	on much lower than a P166 anyway.

Q:	I meet the system requirements but for some reason Jnes slows down so much that 
	running mapper 9 (MMC2) games is impossible why is this?
A:	MMC2 games actually raise the system requirement to more like a p200, this is because
	it uses latches for switching out CHR-ROM, this means every tile that is rendered 
	must be checked against these latches so ensure the proper CHR-ROM bank is loaded, 
	this is painfully slow.

Q:	I can't get sound working, Jnes gives me an error on trying to enable it.
A:	Try downloading Direct X 6.1 from Microsoft and the latest drivers from your vendor, 
	if that does not work ensure the drivers are certified.

Q:	I can't get video working, Jnes gives me an error on on load, or when i try to get
	into full screen mode.
A:	Try downloading Direct X 6.1 from Microsoft and the latest drivers from your vendor, 
	if that does not work ensure the drivers are certified and support the given 
	resolutions. Also make sure you have the correct information file for your Monitor, 
	this is important.

Q:	Which is faster, keyboard reading or joypad reading?
A:	Keyboard reading is faster, joypad polling slows down the emulation ~8 fps.

Q:	<Insert game> doesn't work, it doesn't load correctly, the graphics looked really
	messed up, and its unplayable. What should I do ?
A:	If a rom doesn't work and it looks totally screwed up on, check the rom's header; 
	often times they will include wrong mapper number, an invalid mirroring bit, or it
	will say that the rom uses 4-window VRAM, when in reality it doesn't! If this is the
	case, which does occur dowload a header utility. I recommend using Duper by AshSoft
	from most emulation websites. A final note on this topic,	the rom image you obtained
	may also be a bad dump, in more simple terms during the extraction process a mistake
	was made by the person and the rom is corrupt.

Q:	What's that black 8 pixel wide line going down the left of the screen ?
A:	The nes has a "clipping" feature that clips the left 8 pixels on each scanline, it 
	doesn't actually look that bad, but if it really bothers you use full screen so its
	not as obvious. This is not a bug in the emulator.

Q:	I own a microsoft sidewinder and experience lots of problems using this software,
	is there anything that can help?
A:	I am very aware of this issue. I myself have tested the microsoft sidewinder gamepad
	on Jnes and it worked fine. I make no guarantee of course that it will work, but I've
	been told by people having problems that properly installing and configuring your software
	and drivers should solve it. Jnes supports DirectInput by Microsoft, contact them for help

Q:	I love Castlevania 3 (US), when I tried to load it the error "Unsupported: Mapper #5"
	comes	up, will you ever support it ?
A:	No, there are no plans to support it due to various issues regarding emulation.

Q:	I have some issues using Jnes on Windows NT with Direct X 3.0 installed, what can I do?
A:	I make no guarantee this software will run under NT, this software designed with Windows
	95/98/2000 in mind. As it sits now Direct X builds are no longer being made for NT so I
	can't possibly provide compatibility for it, ask Microsoft for Direct X updates.

Q:	I am having problems with game genie support, I obtained a code for a game and when I use
	it there are some problems with the game. What can I do ?
A:	Some game genie codes are made by hackers and aren't really done properly, use them at
	your own risk. Sometimes as seen they cause really strange behavior, I cannot fix this.

=======
Contact
=======

Please read this documentation before emailing with problems, obviously I know this doc
pretty well so if I know the answer is in here the email will probably be ignored.

Emails regarding locations of games or rom images will be ignored!

Please don't abuse the fact I have place my email address below and do not email with me
complaints or something of a similar nature, this emulator is freeware enjoy it.

I am not interested in giving out the source code to this emulator, I will be porting this
to linux myself sometime in the future.

Author:
-------
Steven Rellinger

http://jnes.vintagegaming.com/
jabo32@hotmail.com

** If the answer to your question is mentioned in this doc, the email will be ignored. **

Read the FAQ above this section!

=======
Credits
=======

Thanks:
-------

The following people assisted to the developement of Jnes, please take note some 
of them I have actually never been in contact with, but their documentation has
proven to be very valuable.

Kevin Horton
Jeremy Chadwick
Terry Chatman
Ben Parnell
Tennessee Carmel-Veilleux
Matthew Conte
Firebug
Nyef
Loopy
Goroh
CyberKefka

Greets:
-------

Ramen

Ash, Infe, opivy10, scar, Traveler, Sych0, AlmtyBob, Dipstick
Flobbasko, blazemore, FuNGiSiDE, herbman, [noam], Zane

Nesdev

_Bnu, Fx3, Akilla, [Delta], CricketNE, EFX, MickOz, _Azimer_, TNSe^1999

==========
Disclaimer
==========

Jnes - Copyright 1999 JaboSoft
The NES is a registered trademark of Nintendo.
Game Genie is a registered trademark of Galoob.

I am not affiliated with Nintendo of America, or any other company mentioned, and 
do not encourage the piracy of NES games, nes games a dirt cheap buy them.

Jnes is freeware and can be distributed freely as long as it is not modified
or distributed with ROM images.

You use this software at your own risk, the author is not responsible for any
loss or damage resulting from the use of this software. If you do not agree with
these terms do not use this software.

[EOF]